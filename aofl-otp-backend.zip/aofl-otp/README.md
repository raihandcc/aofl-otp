# AOFL OTP backend

Vercel serverless endpoints for Twilio Verify.

Environment variables (set in Vercel, never commit secrets):
- TWILIO_ACCOUNT_SID
- TWILIO_AUTH_TOKEN
- TWILIO_VERIFY_SERVICE_SID

POST /api/send-code with JSON `{ "phone": "6045551234", "method": "sms" }` (or `"call"`).
POST /api/verify-code with JSON `{ "phone": "6045551234", "code": "123456" }`.

IMPORTANT before production: restrict CORS to your exact AOFL form origin, add server-side rate limiting and bot protection, and enforce verification server-side at the lead submission endpoint. Client-side verification alone does not prevent bypassed submissions. Never commit tokens. If the website is hosted on a different origin, configure a narrowly scoped CORS policy rather than using a wildcard.
